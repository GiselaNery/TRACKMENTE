
function toggleFields() {
    const cpfField = document.getElementById('cpfField');
    const cnpjField = document.getElementById('cnpjField');
    
    if (document.querySelector('input[name="tipo-cadastro"]:checked').value === 'pf') {
        cpfField.classList.remove('hidden');
        cnpjField.classList.add('hidden');
    } else {
        cpfField.classList.add('hidden');
        cnpjField.classList.remove('hidden');
    }
}

function buscarCep() {
    const cep = document.getElementById('cep').value;
    alert(`Buscando informações para o CEP: ${cep}`);
}
