document.addEventListener("DOMContentLoaded", function() {
    const video = document.getElementById('video');
    const canvas = document.getElementById('canvas');
    const contexto = canvas.getContext('2d');
    const foto = document.getElementById('foto');
    const tirarFotoBtn = document.getElementById('tirarFoto');
    const enviarRelatorioBtn = document.getElementById('enviarRelatorio');
    const baixarFotoBtn = document.getElementById('baixarFoto');

   
   
   // Enviar o relatório ao WhatsApp
enviarRelatorioBtn.addEventListener('click', function() {
    const nomeAluno = document.getElementById('nomeAluno').value;
    const imagemEntrada = document.getElementById('imagemEntrada').files[0];
    const imagemSaida = document.getElementById('imagemSaida').files[0];

    if (!nomeAluno || !imagemEntrada || !imagemSaida) {
        alert("Por favor, preencha todos os campos.");
        return;
    }

    // Criar a mensagem que será enviada
    const mensagem = `Nome do Aluno: ${nomeAluno}\n` +
                     `Imagem de Entrada: ${imagemEntrada.name}\n` +
                     `Imagem de Saída: ${imagemSaida.name}\n` +
                     `Foto Capturada: [link para a foto]`;

    // Substitua '[link para a foto]' pela URL da foto capturada
    const dataUrl = foto.src;
    const whatsappLink = `https://wa.me/?text=${encodeURIComponent(mensagem.replace('[link para a foto]', dataUrl))}`;

    // Abrir o WhatsApp com a mensagem
    window.open(whatsappLink, '_blank');
});
   
   
    // Acessar a câmera
    navigator.mediaDevices.getUserMedia({ video: true })
        .then(function(stream) {
            video.srcObject = stream;
            video.play();
        })
        .catch(function(err) {
            console.error("Erro ao acessar a câmera: " + err);
        });

    // Captura a foto quando o botão é clicado
    tirarFotoBtn.addEventListener('click', function() {
        contexto.drawImage(video, 0, 0, canvas.width, canvas.height);
        // Exibir a imagem capturada
        const dataUrl = canvas.toDataURL('image/png');
        foto.src = dataUrl;
        
        // Habilitar o botão de baixar
        baixarFotoBtn.style.display = 'block'; // Mostra o botão de download
    });

    // Função para baixar a foto
    baixarFotoBtn.addEventListener('click', function() {
        const link = document.createElement('a');
        link.href = foto.src; // A URL da imagem capturada
        link.download = 'foto-capturada.png'; // Nome do arquivo que será baixado
        document.body.appendChild(link);
        link.click(); // Simula o clique para iniciar o download
        document.body.removeChild(link); // Remove o link do DOM
    });

    // Enviar o relatório
    enviarRelatorioBtn.addEventListener('click', function() {
        const nomeAluno = document.getElementById('nomeAluno').value;
        const imagemEntrada = document.getElementById('imagemEntrada').files[0];
        const imagemSaida = document.getElementById('imagemSaida').files[0];

        if (!nomeAluno || !imagemEntrada || !imagemSaida) {
            alert("Por favor, preencha todos os campos.");
            return;
        }

        // Aqui você pode implementar a lógica para enviar o relatório,
        // incluindo o nome do aluno e as imagens
        console.log("Nome do Aluno:", nomeAluno);
        console.log("Imagem de Entrada:", imagemEntrada.name);
        console.log("Imagem de Saída:", imagemSaida.name);
        console.log("Foto Capturada:", foto.src);
    });
});
