function obterLocalizacao() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(mostrarPosicao, tratarErro);
    } else {
        alert("Geolocalização não é suportada por este navegador.");
    }
}

function mostrarPosicao(posicao) {
    const latitude = posicao.coords.latitude;
    const longitude = posicao.coords.longitude;

    // Enviar a localização para o servidor
    enviarLocalizacao(latitude, longitude);
}

function tratarErro(erro) {
    switch(erro.code) {
        case erro.PERMISSION_DENIED:
            alert("Usuário não permitiu a geolocalização.");
            break;
        case erro.POSITION_UNAVAILABLE:
            alert("Localização indisponível.");
            break;
        case erro.TIMEOUT:
            alert("Tempo de solicitação expirado.");
            break;
        case erro.UNKNOWN_ERROR:
            alert("Erro desconhecido.");
            break;
    }
}

function enviarLocalizacao(latitude, longitude) {
    fetch('/api/localizacao', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ latitude, longitude }),
    })
    .then(response => response.json())
    .then(data => {
        console.log('Localização enviada com sucesso:', data);
    })
    .catch((error) => {
        console.error('Erro ao enviar localização:', error);
    });
}

// Chame a função para obter a localização
obterLocalizacao();



