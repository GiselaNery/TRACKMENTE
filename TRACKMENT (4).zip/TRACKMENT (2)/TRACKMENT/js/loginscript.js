function logar(){
    var login = document.getElementById("Usúario").value;
    var senha = document.getElementById("Senha").value


    if(Usúario == admin && Senha == "admin"){
        alert("sucesso");
    }
}



